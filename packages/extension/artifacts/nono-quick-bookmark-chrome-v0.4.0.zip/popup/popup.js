// shared/i18n.js
var zh = {
  quickBookmark: "\u5FEB\u901F\u6536\u85CF",
  connect: "\u8FDE\u63A5",
  connectTitle: "\u8FDE\u63A5 NoNo",
  connectionSettings: "\u8FDE\u63A5\u8BBE\u7F6E",
  closeSettings: "\u5173\u95ED\u8BBE\u7F6E",
  serverUrl: "\u670D\u52A1\u5730\u5740",
  testConnection: "\u6D4B\u8BD5\u8FDE\u63A5",
  saveAndStart: "\u4FDD\u5B58\u5E76\u5F00\u59CB",
  tokenHint: "\u586B\u5165\u540E\u53F0\u521B\u5EFA\u7684 API Token\u3002",
  privacyHint: "\u4EC5\u5728\u4F60\u4E3B\u52A8\u6536\u85CF\u65F6\u8BFB\u53D6\u5F53\u524D\u7F51\u9875\uFF0C\u5E76\u53EA\u53D1\u9001\u5230\u4F60\u914D\u7F6E\u7684 NoNo \u670D\u52A1\u3002",
  language: "\u754C\u9762\u8BED\u8A00",
  readingPage: "\u8BFB\u53D6\u5F53\u524D\u7F51\u9875...",
  readyToSave: "\u51C6\u5907\u6536\u85CF",
  bookmarkName: "\u4E66\u7B7E\u540D\u79F0",
  aiTidy: "AI \u6574\u7406",
  saveTo: "\u4FDD\u5B58\u5230",
  refreshFolders: "\u5237\u65B0\u6587\u4EF6\u5939",
  folder: "\u6587\u4EF6\u5939",
  readyStatus: "\u51C6\u5907\u4FDD\u5B58\u3002",
  saveThisPage: "\u6536\u85CF\u6B64\u9875",
  saveAnotherCopy: "\u53E6\u5B58\u4E00\u4EFD",
  edit: "\u7F16\u8F91",
  collapse: "\u6536\u8D77",
  optional: "\u53EF\u9009",
  extraInfo: "\u8865\u5145\u4FE1\u606F",
  description: "\u63CF\u8FF0",
  popupTitle: "NoNo \u5FEB\u901F\u6536\u85CF",
  duplicateFound: "\u53D1\u73B0\u91CD\u590D\u6536\u85CF",
  updateExisting: "\u66F4\u65B0\u5DF2\u6709",
  openSourceOn: "\u5F00\u6E90\u4E8E",
  feedback: "\u53CD\u9988",
  needServerUrl: "\u8BF7\u8F93\u5165 NoNo \u670D\u52A1\u5730\u5740\u3002",
  needValidServerUrl: "\u8BF7\u8F93\u5165\u6709\u6548\u7684 NoNo \u670D\u52A1\u5730\u5740\u3002",
  needHttps: "\u670D\u52A1\u5730\u5740\u5FC5\u987B\u4F7F\u7528 HTTPS\uFF1B\u672C\u673A\u5F00\u53D1\u53EF\u4F7F\u7528 loopback HTTP\u3002",
  needToken: "\u8BF7\u8F93\u5165 API Token\u3002",
  permissionRequired: "\u9700\u8981\u6388\u6743\u8BBF\u95EE\u8FD9\u4E2A NoNo \u670D\u52A1\u5730\u5740\uFF0C\u8BF7\u70B9\u51FB\u201C\u4FDD\u5B58\u5E76\u5F00\u59CB\u201D\u3002",
  permissionDenied: "\u672A\u83B7\u5F97\u670D\u52A1\u5730\u5740\u8BBF\u95EE\u6743\u9650\u3002",
  tokenNeverExpires: "Token \u4E0D\u8FC7\u671F",
  tokenExpired: "Token \u5DF2\u8FC7\u671F",
  tokenExpiresIn: "Token \u8FD8\u6709 {days} \u5929\u8FC7\u671F",
  otherFolders: "\u5176\u4ED6\u6587\u4EF6\u5939",
  untitledBookmark: "\u672A\u547D\u540D\u4E66\u7B7E",
  invalidServerUrl: "\u670D\u52A1\u5730\u5740\u65E0\u6548\u3002",
  connecting: "\u6B63\u5728\u8FDE\u63A5...",
  savingSettings: "\u4FDD\u5B58\u4E2D...",
  connected: "\u5DF2\u8FDE\u63A5",
  connectFailed: "\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u670D\u52A1\u5730\u5740\u4E0E Token\u3002",
  pickThenSave: "\u9009\u597D\u4F4D\u7F6E\u540E\uFF0C\u4E00\u6B21\u70B9\u51FB\u5373\u53EF\u6536\u85CF\u3002",
  noFolders: "\u8FD8\u6CA1\u6709\u53EF\u7528\u6587\u4EF6\u5939\uFF0C\u8BF7\u5148\u5728 NoNo \u4E2D\u521B\u5EFA\u3002",
  noFoldersOption: "\u6682\u65E0\u6587\u4EF6\u5939",
  foldersRefreshed: "\u6587\u4EF6\u5939\u548C\u91CD\u590D\u72B6\u6001\u5DF2\u5237\u65B0\u3002",
  refreshFailed: "\u5237\u65B0\u5931\u8D25\u3002",
  cannotReadPage: "\u65E0\u6CD5\u8BFB\u53D6\u5F53\u524D\u7F51\u9875\u3002",
  useOnNormalTab: "\u8BF7\u5728\u666E\u901A\u7F51\u9875\u6807\u7B7E\u4E2D\u4F7F\u7528\u5FEB\u901F\u6536\u85CF\u3002",
  pickFolderFirst: "\u8BF7\u5148\u9009\u62E9\u4E00\u4E2A\u6587\u4EF6\u5939\u3002",
  saving: "\u6536\u85CF\u4E2D...",
  saved: "\u5DF2\u6536\u85CF\u5230 NoNo\u3002",
  saveFailed: "\u6536\u85CF\u5931\u8D25\u3002",
  tidying: "\u6574\u7406\u4E2D...",
  tidied: "AI \u5DF2\u8865\u5145\u6807\u9898\u3001\u63CF\u8FF0\u4E0E\u5EFA\u8BAE\u4F4D\u7F6E\u3002",
  tidyFailed: "AI \u6574\u7406\u5931\u8D25\uFF0C\u4ECD\u53EF\u76F4\u63A5\u6536\u85CF\u3002",
  duplicateWarning: "\u5DF2\u6536\u85CF\u4E3A\u300C{name}\u300D\uFF0C\u53EF\u66F4\u65B0\u539F\u8BB0\u5F55\u6216\u53E6\u5B58\u4E00\u4EFD\u3002",
  updating: "\u66F4\u65B0\u4E2D...",
  updatedExisting: "\u5DF2\u6709\u6536\u85CF\u5DF2\u66F4\u65B0\u3002",
  updateFailed: "\u66F4\u65B0\u5DF2\u6709\u6536\u85CF\u5931\u8D25\u3002",
  requestFailed: "\u8BF7\u6C42\u5931\u8D25",
  requestTimedOut: "\u8BF7\u6C42\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5\u670D\u52A1\u662F\u5426\u53EF\u8BBF\u95EE\u3002",
  quickSaveMenu: "\u4FDD\u5B58\u5230 NoNo\uFF08\u4E0A\u6B21\u6587\u4EF6\u5939\uFF09",
  modeBookmark: "\u6536\u85CF",
  modeClip: "\u526A\u85CF",
  clipThisPage: "\u526A\u85CF\u6B64\u9875",
  clipSelection: "\u526A\u85CF\u9009\u533A",
  clipPageMenu: "\u526A\u85CF\u6B64\u9875\u5230 Nono",
  clipSelectionMenu: "\u526A\u85CF\u9009\u533A\u5230 Nono",
  readingArticle: "\u6B63\u5728\u8BFB\u53D6\u6B63\u6587...",
  aiAnalyzeClip: "AI \u5206\u6790",
  analyzingClip: "\u5206\u6790\u4E2D...",
  clipAnalyzed: "AI \u5DF2\u751F\u6210\u6807\u9898\u3001\u6807\u7B7E\u4E0E\u6458\u8981\uFF0C\u53EF\u7EE7\u7EED\u4FEE\u6539\u3002",
  clipAnalyzeFailed: "AI \u5206\u6790\u5931\u8D25\uFF0C\u4ECD\u53EF\u624B\u52A8\u586B\u5199\u540E\u526A\u85CF\u3002",
  clipTitleLabel: "\u6807\u9898",
  clipKeywordsLabel: "\u5173\u952E\u8BCD\uFF08\u6807\u7B7E\uFF09",
  clipKeywordsPlaceholder: "\u4F8B\u5982\uFF1AAI, \u9605\u8BFB, \u5DE5\u5177",
  clipSummaryLabel: "\u6458\u8981",
  clipping: "\u6B63\u5728\u526A\u85CF...",
  clipSaved: "\u5DF2\u526A\u85CF\u3002",
  clipFailed: "\u526A\u85CF\u5931\u8D25\u3002",
  clipScopeMissing: "\u5F53\u524D API Token \u6CA1\u6709\u526A\u85CF\u6743\u9650\u3002\u8BF7\u5728 Nono \u540E\u53F0\u4E3A\u8BE5 Token \u6DFB\u52A0\u526A\u85CF\u4F5C\u7528\u57DF\u540E\u91CD\u8BD5\u3002",
  clipTruncated: "\u6B63\u6587\u5DF2\u6309\u4F53\u79EF\u4E0A\u9650\u622A\u65AD\u3002",
  noSelection: "\u8BF7\u5148\u9009\u4E2D\u4E00\u6BB5\u6587\u5B57\u3002",
  clipWords: "{words} \u5B57",
  pickFolderMenu: "\u9009\u62E9\u6587\u4EF6\u5939\u540E\u4FDD\u5B58\u5230 NoNo",
  bookmarkFailed: "\u6536\u85CF\u5931\u8D25"
};
var en = {
  quickBookmark: "Quick bookmark",
  connect: "Connection",
  connectTitle: "Connect to NoNo",
  connectionSettings: "Connection settings",
  closeSettings: "Close settings",
  serverUrl: "Server URL",
  testConnection: "Test connection",
  saveAndStart: "Save and start",
  tokenHint: "Paste an API token created in the NoNo admin.",
  privacyHint: "The current page is read only when you save and is sent only to the NoNo service you configured.",
  language: "Language",
  readingPage: "Reading the current page\u2026",
  readyToSave: "Ready to save",
  bookmarkName: "Bookmark name",
  aiTidy: "AI tidy",
  saveTo: "Save to",
  refreshFolders: "Refresh folders",
  folder: "Folder",
  readyStatus: "Ready to save.",
  saveThisPage: "Save this page",
  saveAnotherCopy: "Save another copy",
  edit: "Edit",
  collapse: "Collapse",
  optional: "Optional",
  extraInfo: "More details",
  description: "Description",
  popupTitle: "NoNo quick save",
  duplicateFound: "Duplicate found",
  updateExisting: "Update existing",
  openSourceOn: "Open source on",
  feedback: "Feedback",
  needServerUrl: "Enter your NoNo server URL.",
  needValidServerUrl: "Enter a valid NoNo server URL.",
  needHttps: "The server URL must use HTTPS; loopback HTTP is allowed for local development.",
  needToken: "Enter an API token.",
  permissionRequired: "Access to this NoNo server is required. Select \u201CSave and start\u201D to grant it.",
  permissionDenied: "Access to the server address was not granted.",
  tokenNeverExpires: "Token never expires",
  tokenExpired: "Token has expired",
  tokenExpiresIn: "Token expires in {days} days",
  otherFolders: "Other folders",
  untitledBookmark: "Untitled bookmark",
  invalidServerUrl: "That server URL is not valid.",
  connecting: "Connecting\u2026",
  savingSettings: "Saving\u2026",
  connected: "Connected",
  connectFailed: "Could not connect \u2014 check the server URL and token.",
  pickThenSave: "Pick a spot, then save in one click.",
  noFolders: "No folders are available yet. Create one in NoNo first.",
  noFoldersOption: "No folders",
  foldersRefreshed: "Folders and duplicate status refreshed.",
  refreshFailed: "Could not refresh.",
  cannotReadPage: "Could not read the current page.",
  useOnNormalTab: "Use quick save on a normal web page tab.",
  pickFolderFirst: "Choose a folder first.",
  saving: "Saving\u2026",
  saved: "Saved to NoNo.",
  saveFailed: "Could not save.",
  tidying: "Tidying\u2026",
  tidied: "AI filled in the title, description, and a suggested folder.",
  tidyFailed: "AI tidy failed \u2014 you can still save directly.",
  duplicateWarning: "Already saved as \u201C{name}\u201D. Update it or save another copy.",
  updating: "Updating\u2026",
  updatedExisting: "The existing bookmark was updated.",
  updateFailed: "Could not update the existing bookmark.",
  requestFailed: "Request failed",
  requestTimedOut: "The request timed out. Check that the service is reachable.",
  quickSaveMenu: "Save to NoNo (last folder)",
  modeBookmark: "Bookmark",
  modeClip: "Clip",
  clipThisPage: "Clip this page",
  clipSelection: "Clip selection",
  clipPageMenu: "Clip this page to Nono",
  clipSelectionMenu: "Clip selection to Nono",
  readingArticle: "Reading article...",
  aiAnalyzeClip: "AI analyze",
  analyzingClip: "Analyzing...",
  clipAnalyzed: "AI generated a title, tags, and summary. You can still edit them.",
  clipAnalyzeFailed: "AI analysis failed. You can still edit and save the clip.",
  clipTitleLabel: "Title",
  clipKeywordsLabel: "Keywords (tags)",
  clipKeywordsPlaceholder: "For example: AI, Reading, Tools",
  clipSummaryLabel: "Summary",
  clipping: "Clipping...",
  clipSaved: "Clip saved.",
  clipFailed: "Could not save the clip.",
  clipScopeMissing: "This API token has no clip permission. Add the clip scopes to the token in Nono settings, then try again.",
  clipTruncated: "Content was shortened to fit the size limit.",
  noSelection: "Select some text first.",
  clipWords: "{words} words",
  pickFolderMenu: "Choose a folder, then save to NoNo",
  bookmarkFailed: "Could not save the bookmark"
};
var catalogues = { zh, en };
var LOCALE_STORAGE_KEY = "nono:extension-locale";
var active = "zh";
function isLocale(value) {
  return value === "zh" || value === "en";
}
function setLocale(value) {
  active = isLocale(value) ? value : "zh";
  return active;
}
function getLocale() {
  return active;
}
function localeFromUiLanguage(value) {
  const tag = String(value || "").toLowerCase();
  if (tag.startsWith("zh")) return "zh";
  if (tag.startsWith("en")) return "en";
  return null;
}
function t(key, params) {
  const template = catalogues[active]?.[key] ?? zh[key];
  if (template === void 0) return key;
  if (!params) return template;
  return template.replace(/\{(\w+)\}/g, (match, name) => name in params ? String(params[name]) : match);
}

// shared/popup-workflow.js
function normalizeServerUrl(value) {
  const rawUrl = String(value || "").trim();
  if (!rawUrl) throw new Error(t("needServerUrl"));
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error(t("needValidServerUrl"));
  }
  const loopbackHosts = /* @__PURE__ */ new Set(["localhost", "127.0.0.1", "[::1]"]);
  const isSecure = url.protocol === "https:";
  const isLoopbackDevelopment = url.protocol === "http:" && loopbackHosts.has(url.hostname);
  if (!isSecure && !isLoopbackDevelopment) {
    throw new Error(t("needHttps"));
  }
  url.search = "";
  url.hash = "";
  return url.href.replace(/\/+$/, "");
}
function serverOriginPattern(value) {
  const url = new URL(normalizeServerUrl(value));
  return `${url.origin}/*`;
}
function normalizeBookmarkUrl(value) {
  try {
    return new URL(String(value || "").trim()).href.toLowerCase();
  } catch {
    return String(value || "").trim().toLowerCase();
  }
}
function findDuplicateLink(links2, url) {
  const target = normalizeBookmarkUrl(url);
  return links2.find((link) => normalizeBookmarkUrl(link.url) === target) || null;
}
function tokenExpiryText(token, now = /* @__PURE__ */ new Date()) {
  if (!token?.expiresAt) return t("tokenNeverExpires");
  const expiresAt = new Date(token.expiresAt);
  const diff = expiresAt.getTime() - now.getTime();
  if (diff <= 0) return t("tokenExpired");
  const days = Math.max(1, Math.ceil(diff / (24 * 60 * 60 * 1e3)));
  return t("tokenExpiresIn", { days });
}
function buildFolderGroups(folders2) {
  const ordered = [...folders2].sort((left, right) => Number(right.sortOrder || 0) - Number(left.sortOrder || 0));
  const roots = ordered.filter((folder) => !folder.parentId);
  const childrenByParent = new Map(roots.map((folder) => [String(folder.id), []]));
  const orphanFolders = [];
  for (const folder of ordered.filter((folder2) => folder2.parentId)) {
    const children = childrenByParent.get(String(folder.parentId));
    if (children) children.push(folder);
    else orphanFolders.push(folder);
  }
  const groups = roots.map((root) => {
    const children = childrenByParent.get(String(root.id)) || [];
    return { category: root, folders: children.length ? children : [root] };
  });
  if (orphanFolders.length) groups.push({ category: { id: "__other__", name: t("otherFolders") }, folders: orphanFolders });
  return groups;
}
function findFolderGroup(groups, folderId) {
  return groups.find((group) => group.folders.some((folder) => String(folder.id) === String(folderId))) || groups[0] || null;
}
function preferredFolderId(groups, lastFolderId) {
  const hasLastFolder = groups.some((group) => group.folders.some((folder) => String(folder.id) === String(lastFolderId)));
  if (hasLastFolder) return String(lastFolderId);
  return String(groups[0]?.folders[0]?.id || "");
}
function buildQuickSavePayload(pageInfo2, fields) {
  return {
    folderId: Number(fields.folderId),
    name: String(fields.name || pageInfo2.title || new URL(pageInfo2.url).hostname).trim(),
    nameMode: fields.nameMode === "manual" ? "manual" : "auto",
    url: pageInfo2.url,
    description: String(fields.description || pageInfo2.description || "").trim()
  };
}
function buildUpdateBookmarkPayload(pageInfo2, fields) {
  const { nameMode: _nameMode, ...payload } = buildQuickSavePayload(pageInfo2, fields);
  return payload;
}
function compactBookmarkName(value, rawUrl) {
  const fallback = siteNameFromUrl(rawUrl);
  let name = String(value || "").replace(/\s+/g, " ").trim();
  if (!name || /^(home|homepage|index|welcome|untitled|首页|主页|欢迎页)$/i.test(name)) return fallback;
  name = name.split(/[|｜]/, 1)[0].trim();
  const segments = name.split(/\s+(?:—|–|-)\s+/).map((segment) => segment.trim()).filter(Boolean);
  if (segments.length > 1) name = segments[0];
  return truncateToVisualWidth(name, 8);
}
function truncateToVisualWidth(value, maxWidth) {
  let width = 0;
  let result = "";
  let truncated = false;
  for (const character of value) {
    const characterWidth = /\s/.test(character) ? 0.25 : /[\u1100-\u11ff\u2e80-\ua4cf\uac00-\ud7af\uf900-\ufaff\uff01-\uff60\uffe0-\uffe6]/u.test(character) ? 1 : /[A-Za-z0-9]/.test(character) ? 0.55 : 0.45;
    if (width + characterWidth > maxWidth) {
      truncated = true;
      break;
    }
    result += character;
    width += characterWidth;
  }
  if (!truncated) return result;
  if (/[A-Za-z0-9]$/.test(result)) {
    const previousSpace = result.lastIndexOf(" ");
    if (previousSpace > 0) return result.slice(0, previousSpace).trimEnd();
  }
  if (/[A-Za-z0-9]/.test(result) && /[\u1100-\u11ff\u2e80-\ua4cf\uac00-\ud7af\uf900-\ufaff\uff01-\uff60\uffe0-\uffe6]/u.test([...result].at(-1) || "")) return [...result].slice(0, -1).join("").trimEnd();
  return result.trimEnd();
}
function siteNameFromUrl(rawUrl) {
  try {
    const hostname = new URL(rawUrl).hostname.replace(/^www\./, "");
    const known = {
      "bilibili.com": "\u54D4\u54E9\u54D4\u54E9",
      "chatgpt.com": "ChatGPT",
      "developer.mozilla.org": "MDN",
      "github.com": "GitHub",
      "juejin.cn": "\u6398\u91D1",
      "openai.com": "OpenAI",
      "zhihu.com": "\u77E5\u4E4E"
    };
    const match = Object.entries(known).find(([domain]) => hostname === domain || hostname.endsWith(`.${domain}`));
    if (match) return match[1];
    return hostname.split(".").at(-2) || hostname;
  } catch {
    return t("untitledBookmark");
  }
}
function buildClipPayload(article) {
  const payload = {
    url: article.url,
    title: article.title || article.canonicalUrl || article.url,
    contentHtml: article.contentHtml || "",
    contentMd: article.contentMd || "",
    contentTruncated: Boolean(article.contentTruncated),
    extractor: article.extractor || "defuddle"
  };
  if (article.canonicalUrl) payload.canonicalUrl = article.canonicalUrl;
  if (article.author) payload.author = article.author;
  if (article.siteName) payload.siteName = article.siteName;
  if (article.description) payload.description = article.description;
  if (article.lang) payload.lang = article.lang;
  if (article.favicon) payload.favicon = article.favicon;
  if (article.image) payload.image = article.image;
  if (article.publishedAt) payload.publishedAt = article.publishedAt;
  if (Number.isFinite(article.wordCount)) payload.wordCount = article.wordCount;
  if (article.sourceMeta) payload.sourceMeta = article.sourceMeta;
  return payload;
}
function buildClipSavePlan(article, fields = {}) {
  const title = String(fields.title || article.title || article.canonicalUrl || article.url).trim();
  const summary = String(fields.summary ?? article.description ?? "").trim();
  const payload = buildClipPayload({
    ...article,
    title: title || article.canonicalUrl || article.url,
    description: summary
  });
  const seen = /* @__PURE__ */ new Set();
  const tagNames = [];
  for (const raw of String(fields.keywords || "").split(/[,，;；\n]+/u)) {
    const name = raw.replace(/^[#\s]+/u, "").trim().slice(0, 60);
    const key = name.normalize("NFKC").toLocaleLowerCase();
    if (!name || seen.has(key)) continue;
    seen.add(key);
    tagNames.push(name);
    if (tagNames.length === 50) break;
  }
  return { payload, tagNames };
}
function clipErrorMessage(error) {
  if (error?.status === 403) return t("clipScopeMissing");
  return error?.message || t("clipFailed");
}

// popup/popup.js
var languageSelect = document.querySelector("#languageSelect");
var settingsPanel = document.querySelector("#settings");
var workflow = document.querySelector("#workflow");
var details = document.querySelector("#details");
var statusEl = document.querySelector("#status");
var statusLine = document.querySelector(".status-line");
var tokenStatusEl = document.querySelector("#tokenStatus");
var connectionNote = document.querySelector(".connection-note");
var duplicateWarningEl = document.querySelector("#duplicateWarning");
var duplicateMessageEl = document.querySelector("#duplicateMessage");
var duplicateActionButton = document.querySelector("#duplicateAction");
var serverUrlInput = document.querySelector("#serverUrl");
var tokenInput = document.querySelector("#token");
var nameInput = document.querySelector("#name");
var descriptionInput = document.querySelector("#description");
var categorySelect = document.querySelector("#categorySelect");
var folderSelect = document.querySelector("#folderSelect");
var saveButton = document.querySelector("#saveBookmark");
var saveSettingsButton = document.querySelector("#saveSettings");
var testConnectionButton = document.querySelector("#testConnection");
var analyzeButton = document.querySelector("#analyzeBookmark");
var refreshFoldersButton = document.querySelector("#refreshFolders");
var toggleDetailsButton = document.querySelector("#toggleDetails");
var versionLabel = document.querySelector("#versionLabel");
var modeBookmarkButton = document.querySelector("#modeBookmark");
var modeClipButton = document.querySelector("#modeClip");
var pagePreview = document.querySelector("#pagePreview");
var bookmarkPanel = document.querySelector("#bookmarkPanel");
var clipPanel = document.querySelector("#clipPanel");
var clipStatusLine = document.querySelector("#clipStatusLine");
var clipSourceUrl = document.querySelector("#clipSourceUrl");
var clipTitleInput = document.querySelector("#clipTitleInput");
var clipKeywordsInput = document.querySelector("#clipKeywordsInput");
var clipSummaryInput = document.querySelector("#clipSummaryInput");
var clipTruncatedEl = document.querySelector("#clipTruncated");
var analyzeClipButton = document.querySelector("#analyzeClip");
var saveClipButton = document.querySelector("#saveClip");
var saveClipSelectionButton = document.querySelector("#saveClipSelection");
var config = {};
var pageInfo = null;
var folders = [];
var links = [];
var folderGroups = [];
var duplicateLink = null;
var nameMode = "auto";
document.querySelector("#settingsButton").addEventListener("click", openSettings);
document.querySelector("#closeSettings").addEventListener("click", closeSettings);
saveSettingsButton.addEventListener("click", saveSettings);
testConnectionButton.addEventListener("click", testConnectionFromInputs);
refreshFoldersButton.addEventListener("click", refreshFoldersFromButton);
saveButton.addEventListener("click", saveBookmark);
duplicateActionButton.addEventListener("click", updateDuplicateBookmark);
analyzeButton.addEventListener("click", analyzeBookmark);
toggleDetailsButton.addEventListener("click", toggleDetails);
modeBookmarkButton.addEventListener("click", () => setMode("bookmark"));
modeClipButton.addEventListener("click", () => setMode("clip"));
analyzeClipButton.addEventListener("click", analyzeClip);
saveClipButton.addEventListener("click", () => saveClip("NONO_EXTRACT_ARTICLE"));
saveClipSelectionButton.addEventListener("click", () => saveClip("NONO_EXTRACT_SELECTION"));
categorySelect.addEventListener("change", () => renderFolderOptions());
languageSelect?.addEventListener("change", () => changeLanguage(languageSelect.value));
nameInput.addEventListener("input", () => {
  nameMode = "manual";
  if (pageInfo) renderPagePreview();
});
versionLabel.textContent = `v${chrome.runtime.getManifest().version}`;
applyTranslations();
init();
function applyTranslations() {
  for (const el of document.querySelectorAll("[data-i18n]")) el.textContent = t(el.dataset.i18n);
  for (const el of document.querySelectorAll("[data-i18n-title]")) el.title = t(el.dataset.i18nTitle);
  for (const el of document.querySelectorAll("[data-i18n-aria]")) el.setAttribute("aria-label", t(el.dataset.i18nAria));
  for (const el of document.querySelectorAll("[data-i18n-placeholder]")) el.setAttribute("placeholder", t(el.dataset.i18nPlaceholder));
  document.documentElement.lang = getLocale() === "zh" ? "zh-CN" : "en";
  if (languageSelect) languageSelect.value = getLocale();
  renderDetailsLabel();
  renderDuplicateWarning();
}
async function changeLanguage(next) {
  setLocale(next);
  try {
    await chrome.storage.local.set({ [LOCALE_STORAGE_KEY]: getLocale() });
  } catch {
  }
  applyTranslations();
}
async function init() {
  try {
    config = await chrome.storage.local.get(["serverUrl", "token", "lastFolderId", LOCALE_STORAGE_KEY]);
    const stored = config[LOCALE_STORAGE_KEY];
    setLocale(isLocale(stored) ? stored : localeFromUiLanguage(chrome.i18n?.getUILanguage?.()) || "zh");
    applyTranslations();
    serverUrlInput.value = config.serverUrl || "http://localhost:3000";
    tokenInput.value = config.token || "";
    if (!config.serverUrl || !config.token) {
      openSettings();
      return;
    }
    if (!await hasServerPermission(config.serverUrl)) {
      openSettings();
      setTokenStatus(t("permissionRequired"), "error");
      return;
    }
    if (await testConnection(config)) await prepareQuickSave();
    else openSettings();
  } catch (error) {
    openSettings();
    setTokenStatus(error.message || t("connectFailed"), "error");
  }
}
function connectionFromInputs() {
  const token = tokenInput.value.trim();
  if (!token) throw new Error(t("needToken"));
  return { ...config, serverUrl: normalizeServerUrl(serverUrlInput.value), token };
}
async function saveSettings() {
  setBusy(saveSettingsButton, true, t("savingSettings"));
  let candidate = null;
  let previousPattern = null;
  let nextPattern = null;
  try {
    candidate = connectionFromInputs();
    previousPattern = config.serverUrl ? serverOriginPattern(config.serverUrl) : null;
    nextPattern = serverOriginPattern(candidate.serverUrl);
    const granted = await requestServerPermission(candidate.serverUrl);
    if (!granted) throw new Error(t("permissionDenied"));
    if (!await testConnection(candidate)) {
      if (nextPattern !== previousPattern) await chrome.permissions.remove({ origins: [nextPattern] });
      return;
    }
    config = candidate;
    await chrome.storage.local.set({ serverUrl: config.serverUrl, token: config.token });
    if (previousPattern && previousPattern !== nextPattern) {
      await chrome.permissions.remove({ origins: [previousPattern] });
    }
    closeSettings();
    await prepareQuickSave();
  } catch (error) {
    if (nextPattern && nextPattern !== previousPattern) {
      await chrome.permissions.remove({ origins: [nextPattern] }).catch(() => false);
    }
    setTokenStatus(error.message || t("invalidServerUrl"), "error");
  } finally {
    setBusy(saveSettingsButton, false, t("saveAndStart"));
  }
}
async function testConnectionFromInputs() {
  setBusy(testConnectionButton, true, t("connecting"));
  let temporaryPattern = null;
  try {
    const candidate = connectionFromInputs();
    const savedPattern = config.serverUrl ? serverOriginPattern(config.serverUrl) : null;
    const candidatePattern = serverOriginPattern(candidate.serverUrl);
    if (candidatePattern !== savedPattern) temporaryPattern = candidatePattern;
    const granted = await requestServerPermission(candidate.serverUrl);
    if (!granted) throw new Error(t("permissionDenied"));
    await testConnection(candidate);
  } catch (error) {
    setTokenStatus(error.message || t("connectFailed"), "error");
  } finally {
    if (temporaryPattern) await chrome.permissions.remove({ origins: [temporaryPattern] }).catch(() => false);
    setBusy(testConnectionButton, false, t("testConnection"));
  }
}
async function testConnection(connection = config) {
  setTokenStatus(t("connecting"));
  try {
    const [session, token] = await Promise.all([
      request("/api/auth/session", void 0, "GET", connection),
      request("/api/admin/tokens/current", void 0, "GET", connection)
    ]);
    setTokenStatus(`${session.user?.displayName || session.user?.username || t("connected")} \xB7 ${tokenExpiryText(token)}`, "success");
    return true;
  } catch (error) {
    setTokenStatus(error.message || t("connectFailed"), "error");
    return false;
  }
}
async function prepareQuickSave() {
  workflow.classList.remove("hidden");
  settingsPanel.classList.add("hidden");
  setStatus(t("readingPage"));
  try {
    await Promise.all([refreshFolders(), readCurrentPage()]);
    duplicateLink = findDuplicateLink(links, pageInfo.url);
    renderDuplicateWarning();
    setStatus(folderGroups.length ? t("pickThenSave") : t("noFolders"), folderGroups.length ? "" : "error");
  } catch (error) {
    setStatus(error.message || t("cannotReadPage"), "error");
  }
}
async function refreshFoldersFromButton() {
  refreshFoldersButton.disabled = true;
  try {
    await refreshFolders();
    duplicateLink = pageInfo ? findDuplicateLink(links, pageInfo.url) : null;
    renderDuplicateWarning();
    setStatus(folderGroups.length ? t("foldersRefreshed") : t("noFolders"), folderGroups.length ? "success" : "error");
  } catch (error) {
    setStatus(error.message || t("refreshFailed"), "error");
  } finally {
    refreshFoldersButton.disabled = false;
  }
}
async function refreshFolders() {
  try {
    const [folderList, linkList] = await Promise.all([
      request("/api/admin/folders", void 0, "GET"),
      request("/api/admin/links", void 0, "GET")
    ]);
    folders = folderList;
    links = linkList;
    folderGroups = buildFolderGroups(folders);
    renderCategoryOptions();
  } catch (error) {
    folderGroups = [];
    renderCategoryOptions();
    throw error;
  }
}
async function readCurrentPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url || !/^https?:/.test(tab.url)) throw new Error(t("useOnNormalTab"));
  let meta = {};
  try {
    meta = await chrome.tabs.sendMessage(tab.id, { type: "NONO_EXTRACT" });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    meta = await chrome.tabs.sendMessage(tab.id, { type: "NONO_EXTRACT" });
  }
  pageInfo = {
    url: tab.url,
    title: meta.title || tab.title || "",
    description: meta.description || "",
    content: meta.content || "",
    meta
  };
  setAutoName(pageInfo.title);
  descriptionInput.value = pageInfo.description;
  renderPagePreview();
}
async function saveBookmark() {
  if (!pageInfo) return;
  const folderId = folderSelect.value;
  if (!folderId) {
    setStatus(t("pickFolderFirst"), "error");
    return;
  }
  setBusy(saveButton, true, t("saving"));
  try {
    const payload = buildQuickSavePayload(pageInfo, { folderId, name: nameInput.value, nameMode, description: descriptionInput.value });
    const created = await request("/api/admin/links", payload);
    await rememberFolder(folderId);
    links = [created, ...links];
    duplicateLink = findDuplicateLink(links, pageInfo.url);
    renderDuplicateWarning();
    setStatus(t("saved"), "success");
    chrome.action.setBadgeText({ text: "OK" });
  } catch (error) {
    setStatus(error.message || t("saveFailed"), "error");
  } finally {
    setBusy(saveButton, false, duplicateLink ? t("saveAnotherCopy") : t("saveThisPage"));
  }
}
async function updateDuplicateBookmark() {
  if (!pageInfo || !duplicateLink) return;
  const folderId = folderSelect.value;
  if (!folderId) {
    setStatus(t("pickFolderFirst"), "error");
    return;
  }
  setBusy(duplicateActionButton, true, t("updating"));
  try {
    const payload = buildUpdateBookmarkPayload(pageInfo, { folderId, name: nameInput.value, description: descriptionInput.value });
    const updated = await request(`/api/admin/links/${duplicateLink.id}`, payload, "PUT");
    links = links.map((link) => String(link.id) === String(updated.id) ? updated : link);
    duplicateLink = updated;
    await rememberFolder(folderId);
    renderDuplicateWarning();
    setStatus(t("updatedExisting"), "success");
    chrome.action.setBadgeText({ text: "OK" });
  } catch (error) {
    setStatus(error.message || t("updateFailed"), "error");
  } finally {
    setBusy(duplicateActionButton, false, t("updateExisting"));
  }
}
async function analyzeBookmark() {
  if (!pageInfo) return;
  setBusy(analyzeButton, true, t("tidying"));
  try {
    const analysis = await request("/api/ai/analyze", pageInfo);
    setAutoName(analysis.suggestedName || nameInput.value);
    descriptionInput.value = analysis.suggestedDescription || descriptionInput.value;
    const suggestedGroup = findFolderGroup(folderGroups, analysis.suggestedFolderId);
    if (suggestedGroup) {
      categorySelect.value = String(suggestedGroup.category.id);
      renderFolderOptions(analysis.suggestedFolderId);
    }
    setStatus(t("tidied"), "success");
  } catch (error) {
    setStatus(error.message || t("tidyFailed"), "error");
  } finally {
    setBusy(analyzeButton, false, t("aiTidy"));
  }
}
function renderCategoryOptions() {
  categorySelect.innerHTML = "";
  if (!folderGroups.length) {
    addEmptyOption(categorySelect, t("noFoldersOption"));
    addEmptyOption(folderSelect, t("noFoldersOption"));
    categorySelect.disabled = true;
    folderSelect.disabled = true;
    saveButton.disabled = true;
    return;
  }
  for (const group of folderGroups) {
    const option = document.createElement("option");
    option.value = String(group.category.id);
    option.textContent = group.category.name;
    categorySelect.appendChild(option);
  }
  const selectedGroup = findFolderGroup(folderGroups, config.lastFolderId);
  if (selectedGroup) categorySelect.value = String(selectedGroup.category.id);
  categorySelect.disabled = false;
  saveButton.disabled = false;
  renderFolderOptions(config.lastFolderId);
}
function renderFolderOptions(selectedFolderId = "") {
  folderSelect.innerHTML = "";
  const activeGroup = folderGroups.find((group) => String(group.category.id) === categorySelect.value) || folderGroups[0];
  for (const folder of activeGroup?.folders || []) {
    const option = document.createElement("option");
    option.value = String(folder.id);
    option.textContent = folder.name;
    folderSelect.appendChild(option);
  }
  const target = preferredFolderId([activeGroup].filter(Boolean), selectedFolderId || config.lastFolderId);
  if (target) folderSelect.value = target;
  folderSelect.disabled = !folderSelect.options.length;
  saveButton.disabled = !folderSelect.options.length;
}
function addEmptyOption(select, label) {
  select.innerHTML = "";
  const option = document.createElement("option");
  option.value = "";
  option.textContent = label;
  select.appendChild(option);
}
function renderPagePreview() {
  const host = new URL(pageInfo.url).hostname.replace(/^www\./, "");
  document.querySelector("#pageDomain").textContent = host;
  document.querySelector("#pageTitle").textContent = nameInput.value || host;
  document.querySelector("#siteInitial").textContent = host.charAt(0).toUpperCase() || "N";
}
function setAutoName(value) {
  nameMode = "auto";
  nameInput.value = compactBookmarkName(value, pageInfo.url);
}
function renderDuplicateWarning() {
  if (!duplicateWarningEl || !saveButton) return;
  if (!duplicateLink) {
    duplicateWarningEl.classList.add("hidden");
    duplicateMessageEl.textContent = "";
    if (!saveButton.disabled) saveButton.textContent = t("saveThisPage");
    return;
  }
  duplicateMessageEl.textContent = t("duplicateWarning", { name: duplicateLink.name });
  duplicateWarningEl.classList.remove("hidden");
  if (!saveButton.disabled) saveButton.textContent = t("saveAnotherCopy");
}
function toggleDetails() {
  details.classList.toggle("hidden");
  renderDetailsLabel();
}
function renderDetailsLabel() {
  if (!details || !toggleDetailsButton) return;
  const expanded = !details.classList.contains("hidden");
  toggleDetailsButton.textContent = expanded ? t("collapse") : t("edit");
  toggleDetailsButton.setAttribute("aria-expanded", String(expanded));
}
function openSettings() {
  settingsPanel.classList.remove("hidden");
  workflow.classList.add("hidden");
}
function closeSettings() {
  if (!pageInfo) {
    window.close();
    return;
  }
  settingsPanel.classList.add("hidden");
  workflow.classList.remove("hidden");
}
function setBusy(button, busy, label) {
  button.disabled = busy;
  button.textContent = label;
}
function setStatus(message, type = "") {
  statusEl.textContent = message;
  statusLine.className = `status-line${type ? ` ${type}` : ""}`;
}
function setTokenStatus(message, type = "") {
  tokenStatusEl.textContent = message;
  connectionNote.className = `connection-note${type ? ` ${type}` : ""}`;
}
async function rememberFolder(folderId) {
  await chrome.storage.local.set({ lastFolderId: folderId });
  config.lastFolderId = folderId;
}
async function hasServerPermission(serverUrl) {
  return chrome.permissions.contains({ origins: [serverOriginPattern(serverUrl)] });
}
async function requestServerPermission(serverUrl) {
  return chrome.permissions.request({ origins: [serverOriginPattern(serverUrl)] });
}
async function request(path, body, method = "POST", connection = config) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15e3);
  try {
    const response = await fetch(`${normalizeServerUrl(connection.serverUrl)}${path}`, {
      method,
      signal: controller.signal,
      headers: {
        authorization: `Bearer ${connection.token}`,
        ...body === void 0 ? {} : { "content-type": "application/json" }
      },
      ...body === void 0 ? {} : { body: JSON.stringify(body) }
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || payload?.code !== 0) {
      throw Object.assign(
        new Error(payload?.message || `${t("requestFailed")} (${response.status})`),
        { status: response.status }
      );
    }
    return payload.data;
  } catch (error) {
    if (error?.name === "AbortError") throw new Error(t("requestTimedOut"));
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}
var clipMode = "bookmark";
var clipArticle = null;
function setMode(mode) {
  clipMode = mode;
  const clipping = mode === "clip";
  modeBookmarkButton.classList.toggle("is-active", !clipping);
  modeClipButton.classList.toggle("is-active", clipping);
  modeBookmarkButton.setAttribute("aria-selected", String(!clipping));
  modeClipButton.setAttribute("aria-selected", String(clipping));
  bookmarkPanel.classList.toggle("hidden", clipping);
  pagePreview.classList.toggle("hidden", clipping);
  clipPanel.classList.toggle("hidden", !clipping);
  if (clipping && !clipArticle) void loadClipPreview();
}
async function extractFromActiveTab(extractType) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url || !/^https?:/.test(tab.url)) throw new Error(t("useOnNormalTab"));
  try {
    return await chrome.tabs.sendMessage(tab.id, { type: extractType });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    return chrome.tabs.sendMessage(tab.id, { type: extractType });
  }
}
async function loadClipPreview() {
  clipStatusLine.textContent = t("readingArticle");
  try {
    clipArticle = await extractFromActiveTab("NONO_EXTRACT_ARTICLE");
    renderClipEditor(clipArticle);
  } catch (error) {
    clipStatusLine.textContent = error.message || t("clipFailed");
  }
}
function renderClipEditor(article) {
  if (!article) return;
  clipStatusLine.textContent = article.domain || "";
  clipSourceUrl.href = article.url || pageInfo?.url || "";
  clipSourceUrl.textContent = article.url || pageInfo?.url || "";
  clipSourceUrl.title = article.url || pageInfo?.url || "";
  clipTitleInput.value = article.title || pageInfo?.title || "";
  clipKeywordsInput.value = "";
  clipSummaryInput.value = article.description || String(article.contentMd || "").replace(/\s+/g, " ").trim().slice(0, 240);
  clipTruncatedEl.classList.toggle("hidden", !article.contentTruncated);
}
async function analyzeClip() {
  setBusy(analyzeClipButton, true, t("analyzingClip"));
  try {
    if (!clipArticle) clipArticle = await extractFromActiveTab("NONO_EXTRACT_ARTICLE");
    const analysis = await request("/api/ai/analyze", {
      url: clipArticle.url,
      title: clipTitleInput.value || clipArticle.title || "",
      content: String(clipArticle.contentMd || "").slice(0, 5e3),
      meta: clipArticle.sourceMeta || {},
      purpose: "clip"
    });
    clipTitleInput.value = analysis.suggestedName || clipTitleInput.value;
    clipKeywordsInput.value = Array.isArray(analysis.suggestedKeywords) ? analysis.suggestedKeywords.join(", ") : clipKeywordsInput.value;
    clipSummaryInput.value = analysis.suggestedDescription || clipSummaryInput.value;
    setStatus(t("clipAnalyzed"), "success");
  } catch (error) {
    setStatus(error.message || t("clipAnalyzeFailed"), "error");
  } finally {
    setBusy(analyzeClipButton, false, t("aiAnalyzeClip"));
  }
}
async function saveClip(extractType) {
  const button = extractType === "NONO_EXTRACT_SELECTION" ? saveClipSelectionButton : saveClipButton;
  const label = extractType === "NONO_EXTRACT_SELECTION" ? t("clipSelection") : t("clipThisPage");
  setBusy(button, true, t("clipping"));
  try {
    const article = extractType === "NONO_EXTRACT_ARTICLE" && clipArticle ? clipArticle : await extractFromActiveTab(extractType);
    if (!article) throw new Error(t("noSelection"));
    if (extractType === "NONO_EXTRACT_ARTICLE") {
      clipArticle = article;
      renderClipEditor(article);
    }
    const plan = buildClipSavePlan(article, {
      title: clipTitleInput.value,
      keywords: clipKeywordsInput.value,
      summary: clipSummaryInput.value
    });
    const created = await request("/api/clipper/clips", plan.payload);
    if (plan.tagNames.length > 0) {
      const tags = await Promise.all(plan.tagNames.map((name) => request("/api/clipper/tags", { name })));
      const tagIds = [...new Set(tags.map((tag) => Number(tag?.id)).filter(Number.isInteger))];
      if (tagIds.length > 0) await request(`/api/clipper/clips/${created.id}/tags`, { tagIds }, "PUT");
    }
    setStatus(t("clipSaved"), "success");
    chrome.action.setBadgeText({ text: "OK" });
  } catch (error) {
    setStatus(clipErrorMessage(error), "error");
  } finally {
    setBusy(button, false, label);
  }
}
