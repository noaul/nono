// shared/i18n.js
var zh = {
  quickBookmark: "\u5FEB\u901F\u6536\u85CF",
  connect: "\u8FDE\u63A5",
  connectTitle: "\u8FDE\u63A5 NoNo",
  connectionSettings: "\u8FDE\u63A5\u8BBE\u7F6E",
  closeSettings: "\u5173\u95ED\u8BBE\u7F6E",
  serverUrl: "\u670D\u52A1\u5730\u5740",
  testConnection: "\u6D4B\u8BD5\u8FDE\u63A5",
  saveAndStart: "\u4FDD\u5B58\u5E76\u5F00\u59CB",
  tokenHint: "\u586B\u5165\u540E\u53F0\u521B\u5EFA\u7684 API Token\u3002",
  privacyHint: "\u4EC5\u5728\u4F60\u4E3B\u52A8\u6536\u85CF\u65F6\u8BFB\u53D6\u5F53\u524D\u7F51\u9875\uFF0C\u5E76\u53EA\u53D1\u9001\u5230\u4F60\u914D\u7F6E\u7684 NoNo \u670D\u52A1\u3002",
  settingsSaveFailed: "\u6682\u65F6\u65E0\u6CD5\u4FDD\u5B58\u8FDE\u63A5\u8BBE\u7F6E\u3002",
  language: "\u754C\u9762\u8BED\u8A00",
  readingPage: "\u8BFB\u53D6\u5F53\u524D\u7F51\u9875...",
  readyToSave: "\u51C6\u5907\u6536\u85CF",
  bookmarkName: "\u4E66\u7B7E\u540D\u79F0",
  aiTidy: "AI \u6574\u7406",
  saveTo: "\u4FDD\u5B58\u5230",
  refreshFolders: "\u5237\u65B0\u6587\u4EF6\u5939",
  folder: "\u6587\u4EF6\u5939",
  readyStatus: "\u51C6\u5907\u4FDD\u5B58\u3002",
  saveThisPage: "\u6536\u85CF\u6B64\u9875",
  saveAnotherCopy: "\u53E6\u5B58\u4E00\u4EFD",
  edit: "\u7F16\u8F91",
  collapse: "\u6536\u8D77",
  optional: "\u53EF\u9009",
  extraInfo: "\u8865\u5145\u4FE1\u606F",
  description: "\u63CF\u8FF0",
  popupTitle: "NoNo \u5FEB\u901F\u6536\u85CF",
  duplicateFound: "\u53D1\u73B0\u91CD\u590D\u6536\u85CF",
  updateExisting: "\u66F4\u65B0\u5DF2\u6709",
  openSourceOn: "\u5F00\u6E90\u4E8E",
  feedback: "\u53CD\u9988",
  needServerUrl: "\u8BF7\u8F93\u5165 NoNo \u670D\u52A1\u5730\u5740\u3002",
  needValidServerUrl: "\u8BF7\u8F93\u5165\u6709\u6548\u7684 NoNo \u670D\u52A1\u5730\u5740\u3002",
  needHttps: "\u670D\u52A1\u5730\u5740\u5FC5\u987B\u4F7F\u7528 HTTPS\uFF1B\u672C\u673A\u5F00\u53D1\u53EF\u4F7F\u7528 loopback HTTP\u3002",
  needToken: "\u8BF7\u8F93\u5165 API Token\u3002",
  permissionRequired: "\u9700\u8981\u6388\u6743\u8BBF\u95EE\u8FD9\u4E2A NoNo \u670D\u52A1\u5730\u5740\uFF0C\u8BF7\u70B9\u51FB\u201C\u4FDD\u5B58\u5E76\u5F00\u59CB\u201D\u3002",
  permissionDenied: "\u672A\u83B7\u5F97\u670D\u52A1\u5730\u5740\u8BBF\u95EE\u6743\u9650\u3002",
  tokenNeverExpires: "Token \u4E0D\u8FC7\u671F",
  tokenExpired: "Token \u5DF2\u8FC7\u671F",
  tokenExpiresIn: "Token \u8FD8\u6709 {days} \u5929\u8FC7\u671F",
  otherFolders: "\u5176\u4ED6\u6587\u4EF6\u5939",
  untitledBookmark: "\u672A\u547D\u540D\u4E66\u7B7E",
  invalidServerUrl: "\u670D\u52A1\u5730\u5740\u65E0\u6548\u3002",
  connecting: "\u6B63\u5728\u8FDE\u63A5...",
  savingSettings: "\u4FDD\u5B58\u4E2D...",
  connected: "\u5DF2\u8FDE\u63A5",
  connectFailed: "\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u670D\u52A1\u5730\u5740\u4E0E Token\u3002",
  pickThenSave: "\u9009\u597D\u4F4D\u7F6E\u540E\uFF0C\u4E00\u6B21\u70B9\u51FB\u5373\u53EF\u6536\u85CF\u3002",
  noFolders: "\u8FD8\u6CA1\u6709\u53EF\u7528\u6587\u4EF6\u5939\uFF0C\u8BF7\u5148\u5728 NoNo \u4E2D\u521B\u5EFA\u3002",
  noFoldersOption: "\u6682\u65E0\u6587\u4EF6\u5939",
  foldersRefreshed: "\u6587\u4EF6\u5939\u548C\u91CD\u590D\u72B6\u6001\u5DF2\u5237\u65B0\u3002",
  refreshFailed: "\u5237\u65B0\u5931\u8D25\u3002",
  cannotReadPage: "\u65E0\u6CD5\u8BFB\u53D6\u5F53\u524D\u7F51\u9875\u3002",
  useOnNormalTab: "\u8BF7\u5728\u666E\u901A\u7F51\u9875\u6807\u7B7E\u4E2D\u4F7F\u7528\u5FEB\u901F\u6536\u85CF\u3002",
  pickFolderFirst: "\u8BF7\u5148\u9009\u62E9\u4E00\u4E2A\u6587\u4EF6\u5939\u3002",
  saving: "\u6536\u85CF\u4E2D...",
  saved: "\u5DF2\u6536\u85CF\u5230 NoNo\u3002",
  saveFailed: "\u6536\u85CF\u5931\u8D25\u3002",
  tidying: "\u6574\u7406\u4E2D...",
  tidied: "AI \u5DF2\u8865\u5145\u6807\u9898\u3001\u63CF\u8FF0\u4E0E\u5EFA\u8BAE\u4F4D\u7F6E\u3002",
  tidyFailed: "AI \u6574\u7406\u5931\u8D25\uFF0C\u4ECD\u53EF\u76F4\u63A5\u6536\u85CF\u3002",
  duplicateWarning: "\u5DF2\u6536\u85CF\u4E3A\u300C{name}\u300D\uFF0C\u53EF\u66F4\u65B0\u539F\u8BB0\u5F55\u6216\u53E6\u5B58\u4E00\u4EFD\u3002",
  updating: "\u66F4\u65B0\u4E2D...",
  updatedExisting: "\u5DF2\u6709\u6536\u85CF\u5DF2\u66F4\u65B0\u3002",
  updateFailed: "\u66F4\u65B0\u5DF2\u6709\u6536\u85CF\u5931\u8D25\u3002",
  requestFailed: "\u8BF7\u6C42\u5931\u8D25",
  requestTimedOut: "\u8BF7\u6C42\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5\u670D\u52A1\u662F\u5426\u53EF\u8BBF\u95EE\u3002",
  quickSaveMenu: "\u4FDD\u5B58\u5230 NoNo\uFF08\u4E0A\u6B21\u6587\u4EF6\u5939\uFF09",
  pickFolderMenu: "\u9009\u62E9\u6587\u4EF6\u5939\u540E\u4FDD\u5B58\u5230 NoNo",
  bookmarkFailed: "\u6536\u85CF\u5931\u8D25"
};
var en = {
  quickBookmark: "Quick bookmark",
  connect: "Connection",
  connectTitle: "Connect to NoNo",
  connectionSettings: "Connection settings",
  closeSettings: "Close settings",
  serverUrl: "Server URL",
  testConnection: "Test connection",
  saveAndStart: "Save and start",
  tokenHint: "Paste an API token created in the NoNo admin.",
  privacyHint: "The current page is read only when you save and is sent only to the NoNo service you configured.",
  settingsSaveFailed: "Connection settings could not be saved.",
  language: "Language",
  readingPage: "Reading the current page\u2026",
  readyToSave: "Ready to save",
  bookmarkName: "Bookmark name",
  aiTidy: "AI tidy",
  saveTo: "Save to",
  refreshFolders: "Refresh folders",
  folder: "Folder",
  readyStatus: "Ready to save.",
  saveThisPage: "Save this page",
  saveAnotherCopy: "Save another copy",
  edit: "Edit",
  collapse: "Collapse",
  optional: "Optional",
  extraInfo: "More details",
  description: "Description",
  popupTitle: "NoNo quick save",
  duplicateFound: "Duplicate found",
  updateExisting: "Update existing",
  openSourceOn: "Open source on",
  feedback: "Feedback",
  needServerUrl: "Enter your NoNo server URL.",
  needValidServerUrl: "Enter a valid NoNo server URL.",
  needHttps: "The server URL must use HTTPS; loopback HTTP is allowed for local development.",
  needToken: "Enter an API token.",
  permissionRequired: "Access to this NoNo server is required. Select \u201CSave and start\u201D to grant it.",
  permissionDenied: "Access to the server address was not granted.",
  tokenNeverExpires: "Token never expires",
  tokenExpired: "Token has expired",
  tokenExpiresIn: "Token expires in {days} days",
  otherFolders: "Other folders",
  untitledBookmark: "Untitled bookmark",
  invalidServerUrl: "That server URL is not valid.",
  connecting: "Connecting\u2026",
  savingSettings: "Saving\u2026",
  connected: "Connected",
  connectFailed: "Could not connect \u2014 check the server URL and token.",
  pickThenSave: "Pick a spot, then save in one click.",
  noFolders: "No folders are available yet. Create one in NoNo first.",
  noFoldersOption: "No folders",
  foldersRefreshed: "Folders and duplicate status refreshed.",
  refreshFailed: "Could not refresh.",
  cannotReadPage: "Could not read the current page.",
  useOnNormalTab: "Use quick save on a normal web page tab.",
  pickFolderFirst: "Choose a folder first.",
  saving: "Saving\u2026",
  saved: "Saved to NoNo.",
  saveFailed: "Could not save.",
  tidying: "Tidying\u2026",
  tidied: "AI filled in the title, description, and a suggested folder.",
  tidyFailed: "AI tidy failed \u2014 you can still save directly.",
  duplicateWarning: "Already saved as \u201C{name}\u201D. Update it or save another copy.",
  updating: "Updating\u2026",
  updatedExisting: "The existing bookmark was updated.",
  updateFailed: "Could not update the existing bookmark.",
  requestFailed: "Request failed",
  requestTimedOut: "The request timed out. Check that the service is reachable.",
  quickSaveMenu: "Save to NoNo (last folder)",
  pickFolderMenu: "Choose a folder, then save to NoNo",
  bookmarkFailed: "Could not save the bookmark"
};
var catalogues = { zh, en };
var LOCALE_STORAGE_KEY = "nono:extension-locale";
var active = "zh";
function isLocale(value) {
  return value === "zh" || value === "en";
}
function setLocale(value) {
  active = isLocale(value) ? value : "zh";
  return active;
}
function localeFromUiLanguage(value) {
  const tag = String(value || "").toLowerCase();
  if (tag.startsWith("zh")) return "zh";
  if (tag.startsWith("en")) return "en";
  return null;
}
function t(key, params) {
  const template = catalogues[active]?.[key] ?? zh[key];
  if (template === void 0) return key;
  if (!params) return template;
  return template.replace(/\{(\w+)\}/g, (match, name) => name in params ? String(params[name]) : match);
}

// shared/popup-workflow.js
function normalizeServerUrl(value) {
  const rawUrl = String(value || "").trim();
  if (!rawUrl) throw new Error(t("needServerUrl"));
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error(t("needValidServerUrl"));
  }
  const loopbackHosts = /* @__PURE__ */ new Set(["localhost", "127.0.0.1", "[::1]"]);
  const isSecure = url.protocol === "https:";
  const isLoopbackDevelopment = url.protocol === "http:" && loopbackHosts.has(url.hostname);
  if (!isSecure && !isLoopbackDevelopment) {
    throw new Error(t("needHttps"));
  }
  url.search = "";
  url.hash = "";
  return url.href.replace(/\/+$/, "");
}
function serverOriginPattern(value) {
  const url = new URL(normalizeServerUrl(value));
  return `${url.origin}/*`;
}

// background.js
var QUICK_SAVE_MENU_ID = "nono-quick-save";
var OPEN_MENU_ID = "nono-open-save";
chrome.runtime.onInstalled.addListener(async () => {
  chrome.action.setBadgeBackgroundColor({ color: "#167d86" });
  await syncContextMenus();
});
chrome.runtime.onStartup.addListener(() => syncContextMenus());
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !(LOCALE_STORAGE_KEY in changes)) return;
  setLocale(resolveLocale(changes[LOCALE_STORAGE_KEY]?.newValue));
  void createContextMenus();
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === OPEN_MENU_ID) {
    await chrome.action.openPopup();
    return;
  }
  if (info.menuItemId === QUICK_SAVE_MENU_ID && tab) await quickSave(tab);
});
chrome.commands.onCommand.addListener(async (command) => {
  if (command === "open-quick-save") await chrome.action.openPopup();
  if (command === "quick-save-last-folder") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) await quickSave(tab);
  }
});
async function createContextMenus() {
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({ id: QUICK_SAVE_MENU_ID, title: t("quickSaveMenu"), contexts: ["page"] });
  chrome.contextMenus.create({ id: OPEN_MENU_ID, title: t("pickFolderMenu"), contexts: ["page"] });
}
async function syncContextMenus() {
  const stored = await chrome.storage.local.get([LOCALE_STORAGE_KEY]);
  setLocale(resolveLocale(stored[LOCALE_STORAGE_KEY]));
  await createContextMenus();
}
function resolveLocale(stored) {
  return isLocale(stored) ? stored : localeFromUiLanguage(chrome.i18n?.getUILanguage?.()) || "zh";
}
async function quickSave(tab) {
  if (!tab.url || !/^https?:/.test(tab.url)) return;
  const { serverUrl, token, lastFolderId } = await chrome.storage.local.get(["serverUrl", "token", "lastFolderId"]);
  if (!serverUrl || !token || !lastFolderId) {
    await chrome.action.openPopup();
    return;
  }
  if (!await chrome.permissions.contains({ origins: [serverOriginPattern(serverUrl)] })) {
    await chrome.action.openPopup();
    return;
  }
  try {
    const response = await fetch(`${normalizeServerUrl(serverUrl)}/api/admin/links`, {
      method: "POST",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
      body: JSON.stringify({ folderId: Number(lastFolderId), name: tab.title || new URL(tab.url).hostname, nameMode: "auto", url: tab.url, description: "" })
    });
    const payload = await response.json();
    if (payload.code !== 0) throw new Error(payload.message || t("bookmarkFailed"));
    chrome.action.setBadgeText({ text: "OK", tabId: tab.id });
  } catch {
    chrome.action.setBadgeText({ text: "!", tabId: tab.id });
  }
}
